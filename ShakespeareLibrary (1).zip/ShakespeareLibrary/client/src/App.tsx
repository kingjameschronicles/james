import { useEffect, useState } from "react";
import { useAudio } from "./lib/stores/useAudio";
import { useLibraryGame } from "./lib/stores/useLibraryGame";
import GameCanvas from "./components/GameCanvas";
import StartScreen from "./components/StartScreen";
import BookContent from "./components/BookContent";
import "@fontsource/inter";
import "./index.css";

function App() {
  const gameState = useLibraryGame((state) => state.gameState);
  const activeBook = useLibraryGame((state) => state.activeBook);
  const closeBook = useLibraryGame((state) => state.closeBook);
  const { setBackgroundMusic } = useAudio();
  const [isLoading, setIsLoading] = useState(true);

  // Debug log when component mounts
  useEffect(() => {
    console.log("App component mounted");
  }, []);

  // Debug log when game state changes
  useEffect(() => {
    console.log("Game state changed:", gameState);
  }, [gameState]);

  // Load audio assets
  useEffect(() => {
    console.log("Loading audio assets...");
    
    try {
      // Create background music
      console.log("Creating background music...");
      const bgMusic = new Audio("/sounds/background.mp3");
      bgMusic.loop = true;
      bgMusic.volume = 0.3;
      setBackgroundMusic(bgMusic);
      console.log("Background music created successfully");
      
      // Set up hit sound
      console.log("Creating hit sound...");
      const hitSfx = new Audio("/sounds/hit.mp3");
      useAudio.getState().setHitSound(hitSfx);
      console.log("Hit sound created successfully");
      
      // Set up success sound
      console.log("Creating success sound...");
      const successSfx = new Audio("/sounds/success.mp3");
      useAudio.getState().setSuccessSound(successSfx);
      console.log("Success sound created successfully");
      
      console.log("All audio assets loaded successfully");
      setIsLoading(false);
    } catch (error) {
      console.error("Error loading audio assets:", error);
      // Continue even if audio fails to load
      setIsLoading(false);
    }
  }, [setBackgroundMusic]);

  // Debug log when loading state changes
  useEffect(() => {
    console.log("Loading state changed:", isLoading);
  }, [isLoading]);

  if (isLoading) {
    console.log("Rendering loading screen");
    return (
      <div className="loading-screen">
        <div className="spinner"></div>
        <p>Loading the King's Library...</p>
      </div>
    );
  }

  console.log("Rendering main app with game state:", gameState);
  console.log("Active book:", activeBook);

  return (
    <div className="game-container">
      {gameState === "start" && (
        <>
          {console.log("Rendering start screen")}
          <StartScreen />
        </>
      )}
      
      {gameState === "playing" && (
        <>
          {console.log("Rendering game canvas")}
          <GameCanvas />
          <div className="controls-hint">
            <p>Use WASD or Arrow Keys to move | Press E to interact with books</p>
          </div>
        </>
      )}
      
      {activeBook && (
        <>
          {console.log("Rendering book content for:", activeBook.title)}
          <BookContent book={activeBook} onClose={closeBook} />
        </>
      )}
    </div>
  );
}

export default App;
