import { LibraryObject } from "./stores/useLibraryGame";

// Check if a point is inside a rectangle
export function pointInRect(
  point: [number, number],
  rect: { position: [number, number]; size: [number, number] }
): boolean {
  const [px, py] = point;
  const [rx, ry] = rect.position;
  const [rw, rh] = rect.size;
  
  const left = rx - rw / 2;
  const right = rx + rw / 2;
  const top = ry - rh / 2;
  const bottom = ry + rh / 2;
  
  return px >= left && px <= right && py >= top && py <= bottom;
}

// Check if two rectangles overlap
export function rectOverlap(
  rect1: { position: [number, number]; size: [number, number] },
  rect2: { position: [number, number]; size: [number, number] }
): boolean {
  const [x1, y1] = rect1.position;
  const [w1, h1] = rect1.size;
  const [x2, y2] = rect2.position;
  const [w2, h2] = rect2.size;
  
  const left1 = x1 - w1 / 2;
  const right1 = x1 + w1 / 2;
  const top1 = y1 - h1 / 2;
  const bottom1 = y1 + h1 / 2;
  
  const left2 = x2 - w2 / 2;
  const right2 = x2 + w2 / 2;
  const top2 = y2 - h2 / 2;
  const bottom2 = y2 + h2 / 2;
  
  return !(
    right1 < left2 ||
    left1 > right2 ||
    bottom1 < top2 ||
    top1 > bottom2
  );
}

// Calculate distance between two points
export function distance(point1: [number, number], point2: [number, number]): number {
  const dx = point2[0] - point1[0];
  const dy = point2[1] - point1[1];
  return Math.sqrt(dx * dx + dy * dy);
}

// Find nearest solid object to a point
export function findNearestObject(
  point: [number, number],
  objects: LibraryObject[]
): LibraryObject | null {
  let nearest: LibraryObject | null = null;
  let minDistance = Infinity;
  
  for (const obj of objects) {
    if (!obj.solid) continue;
    
    const dist = distance(point, obj.position);
    if (dist < minDistance) {
      minDistance = dist;
      nearest = obj;
    }
  }
  
  return nearest;
}

// Normalize a vector
export function normalizeVector(vector: [number, number]): [number, number] {
  const magnitude = Math.sqrt(vector[0] * vector[0] + vector[1] * vector[1]);
  
  if (magnitude === 0) {
    return [0, 0];
  }
  
  return [vector[0] / magnitude, vector[1] / magnitude];
}

// Convert direction enum to vector
export function directionToVector(
  direction: "up" | "down" | "left" | "right"
): [number, number] {
  switch (direction) {
    case "up": return [0, -1];
    case "down": return [0, 1];
    case "left": return [-1, 0];
    case "right": return [1, 0];
    default: return [0, 0];
  }
}
