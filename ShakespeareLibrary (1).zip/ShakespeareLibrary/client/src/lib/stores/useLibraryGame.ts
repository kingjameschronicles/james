import { create } from "zustand";

// Types
export type GameState = "start" | "playing" | "paused";
export type PlayerDirection = "up" | "down" | "left" | "right";
export type LibraryObjectType = "bookshelf" | "table" | "chair" | "desk" | "plant";

export interface BookData {
  id: number;
  title: string;
  position: [number, number];
  color: string;
  content: string[];
  image?: string;
}

export interface LibraryObject {
  type: LibraryObjectType;
  position: [number, number];
  size: [number, number];
  solid: boolean;
}

interface LibraryGameState {
  // Game state
  gameState: GameState;
  playerPosition: [number, number];
  playerDirection: PlayerDirection;
  playerVelocity: [number, number];
  playerSpeed: number;
  
  // Library and books
  books: BookData[];
  libraryLayout: LibraryObject[];
  highlightedBookId: number | null;
  activeBook: BookData | null;
  
  // Actions
  initializeGame: () => void;
  startGame: () => void;
  movePlayer: (direction: [number, number]) => void;
  updateGameState: (deltaTime: number) => void;
  checkCollisions: () => void;
  highlightBook: (id: number | null) => void;
  checkBookInteraction: () => void;
  openBook: (id: number) => void;
  closeBook: () => void;
}

export const useLibraryGame = create<LibraryGameState>((set, get) => ({
  // Initial game state
  gameState: "start",
  playerPosition: [400, 500],
  playerDirection: "down",
  playerVelocity: [0, 0],
  playerSpeed: 3,
  
  // Initialize books with content about King James I and Shakespeare
  books: [
    {
      id: 1,
      title: "Royal Patronage of the Theater",
      position: [250, 200],
      color: "#8B4513",
      content: [
        "In 1603, King James I became a significant patron of the theater in England, taking Shakespeare's company under his direct royal protection.",
        "He officially adopted the Lord Chamberlain's Men, renaming them 'The King's Men,' which elevated their status considerably in London society.",
        "This royal patronage provided the company with a steady stream of performances at court and financial stability during a time when theaters often struggled.",
        "During the first year of James's reign alone, The King's Men performed eight different plays at court, showcasing the monarch's enthusiasm for theatrical entertainment.",
        "The royal patronage also protected the company from some of the puritan opposition to theaters that was growing during this period."
      ],
      image: "patronage"
    },
    {
      id: 2,
      title: "Macbeth: A Play for the King",
      position: [600, 250],
      color: "#800020",
      content: [
        "Shakespeare wrote 'Macbeth' around 1606, specifically tailoring it to appeal to King James I's interests and background.",
        "The play is set in Scotland, James's homeland, and features his ancestor Banquo as a noble character who would father a line of kings.",
        "Macbeth deals extensively with witchcraft, a subject that fascinated King James I, who had even published his own book 'Daemonologie' on the topic in 1597.",
        "The three witches in the play reflect James's belief in and fear of witchcraft, which he considered a serious threat to his reign.",
        "The theme of regicide (king-killing) in Macbeth would have been particularly resonant following the Gunpowder Plot of 1605, a failed assassination attempt against James I."
      ],
      image: "macbeth"
    },
    {
      id: 3,
      title: "Uniting the Kingdoms",
      position: [150, 450],
      color: "#4682B4",
      content: [
        "King James I had a strong political ambition to unite England and Scotland under one crown, creating what he called 'Great Britain.'",
        "Shakespeare's plays written during James's reign, particularly 'King Lear' and 'Cymbeline,' subtly support this unification agenda.",
        "In 'Cymbeline,' Shakespeare presents a narrative of Britain coming together under one rule, reflecting James's desire to unite the kingdoms.",
        "These plays often present division as destructive and unification as the path to peace and prosperity, mirroring the king's political messaging.",
        "By incorporating these themes, Shakespeare was not only entertaining his audience but also helping to promote the king's political agenda."
      ],
      image: "kingdoms"
    },
    {
      id: 4,
      title: "The Globe Theater Under James I",
      position: [720, 500],
      color: "#2E8B57",
      content: [
        "The Globe Theater, where many of Shakespeare's plays were performed, flourished under King James I's reign.",
        "As members of The King's Men, Shakespeare and his colleagues received special status, including royal livery to wear on ceremonial occasions.",
        "The company performed regularly at the Globe for public audiences while also being summoned to perform at court for the king and his guests.",
        "Records show that performances at court increased dramatically under James I compared to Queen Elizabeth's reign, demonstrating his greater enthusiasm for theater.",
        "This dual audience—public and royal—influenced how Shakespeare crafted his plays, allowing them to work on multiple levels of meaning."
      ],
      image: "globe"
    },
    {
      id: 5,
      title: "Legacy of Royal Patronage",
      position: [450, 350],
      color: "#9370DB",
      content: [
        "King James I's patronage had a lasting impact on theater beyond Shakespeare's immediate career and company.",
        "The elevated status of The King's Men set a new standard for professional theater companies and helped establish acting as a more respectable profession.",
        "James's support for the arts encouraged other noblemen to become patrons of theater companies, expanding the cultural landscape of early 17th century England.",
        "The theatrical innovations that occurred under James's reign—in staging, writing, and performance—influenced English drama for generations to come.",
        "Many scholars consider the Jacobean period (named after James) to be one of the richest and most inventive eras in English theatrical history."
      ],
      image: "legacy"
    }
  ],
  
  // Library layout with objects (bookshelves, tables, etc.)
  libraryLayout: [
    // Bookshelves along walls
    { type: "bookshelf", position: [100, 100], size: [200, 40], solid: true },
    { type: "bookshelf", position: [350, 100], size: [200, 40], solid: true },
    { type: "bookshelf", position: [600, 100], size: [200, 40], solid: true },
    { type: "bookshelf", position: [100, 600], size: [200, 40], solid: true },
    { type: "bookshelf", position: [350, 600], size: [200, 40], solid: true },
    { type: "bookshelf", position: [600, 600], size: [200, 40], solid: true },
    { type: "bookshelf", position: [800, 250], size: [40, 150], solid: true },
    { type: "bookshelf", position: [800, 450], size: [40, 150], solid: true },
    { type: "bookshelf", position: [100, 250], size: [40, 150], solid: true },
    { type: "bookshelf", position: [100, 450], size: [40, 150], solid: true },
    
    // Tables and chairs in the center
    { type: "table", position: [400, 300], size: [120, 80], solid: true },
    { type: "chair", position: [350, 300], size: [40, 40], solid: false },
    { type: "chair", position: [450, 300], size: [40, 40], solid: false },
    { type: "chair", position: [400, 250], size: [40, 40], solid: false },
    { type: "chair", position: [400, 350], size: [40, 40], solid: false },
    
    // Reading desks
    { type: "desk", position: [200, 300], size: [80, 60], solid: true },
    { type: "chair", position: [200, 350], size: [40, 40], solid: false },
    { type: "desk", position: [600, 300], size: [80, 60], solid: true },
    { type: "chair", position: [600, 350], size: [40, 40], solid: false },
    
    // Decorative plants
    { type: "plant", position: [150, 150], size: [40, 40], solid: true },
    { type: "plant", position: [650, 150], size: [40, 40], solid: true },
    { type: "plant", position: [150, 550], size: [40, 40], solid: true },
    { type: "plant", position: [650, 550], size: [40, 40], solid: true }
  ],
  
  highlightedBookId: null,
  activeBook: null,
  
  // Initialize game
  initializeGame: () => {
    console.log("useLibraryGame: Initializing game");
    // Get current state first
    const currentState = get().gameState;
    console.log("useLibraryGame: Current game state before init:", currentState);
    
    // Reset player position and other non-game state values
    const initialPlayerPosition: [number, number] = [400, 500];
    
    // Only change game state if not already playing or paused
    if (currentState === "playing" || currentState === "paused") {
      console.log("useLibraryGame: Already in", currentState, "state - keeping existing game state");
      set({
        playerPosition: initialPlayerPosition,
        playerDirection: "down",
        playerVelocity: [0, 0],
        highlightedBookId: null,
        activeBook: null
      });
    } else {
      console.log("useLibraryGame: Setting game state to 'start'");
      set({
        gameState: "start",
        playerPosition: initialPlayerPosition,
        playerDirection: "down",
        playerVelocity: [0, 0],
        highlightedBookId: null,
        activeBook: null
      });
    }
  },
  
  // Start game
  startGame: () => {
    console.log("useLibraryGame: Starting game - setting state to playing");
    set(state => {
      // Only update if we're not already playing
      if (state.gameState === "start") {
        console.log("useLibraryGame: State was 'start', now changing to 'playing'");
        return { gameState: "playing" };
      }
      console.log("useLibraryGame: State was already", state.gameState, "- no change needed");
      return state;
    });
  },
  
  // Move player
  movePlayer: (direction: [number, number]) => {
    const { playerDirection } = get();
    let newDirection: PlayerDirection = playerDirection;
    
    // Update player direction based on movement input
    if (direction[0] < 0) newDirection = "left";
    else if (direction[0] > 0) newDirection = "right";
    else if (direction[1] < 0) newDirection = "up";
    else if (direction[1] > 0) newDirection = "down";
    
    set({ 
      playerVelocity: direction,
      playerDirection: newDirection
    });
  },
  
  // Update game state (called in animation loop)
  updateGameState: (deltaTime: number) => {
    const { playerPosition, playerVelocity, playerSpeed, gameState } = get();
    
    if (gameState !== "playing") return;
    
    // Only update if player is moving
    if (playerVelocity[0] !== 0 || playerVelocity[1] !== 0) {
      // Normalize diagonal movement
      let speedMultiplier = 1;
      if (playerVelocity[0] !== 0 && playerVelocity[1] !== 0) {
        speedMultiplier = 0.7071; // 1 / sqrt(2)
      }
      
      // Calculate new position
      const newPosition: [number, number] = [
        playerPosition[0] + playerVelocity[0] * playerSpeed * speedMultiplier,
        playerPosition[1] + playerVelocity[1] * playerSpeed * speedMultiplier
      ];
      
      // Check boundaries
      const boundX = Math.max(50, Math.min(newPosition[0], 850));
      const boundY = Math.max(50, Math.min(newPosition[1], 650));
      
      set({ playerPosition: [boundX, boundY] });
    }
    
    // Reset velocity (for smooth movement, we'll reapply it on keydown)
    set({ playerVelocity: [0, 0] });
  },
  
  // Check collisions with library objects
  checkCollisions: () => {
    const { playerPosition, libraryLayout } = get();
    
    // Player hitbox (simplified as a circle)
    const playerRadius = 20;
    
    // Check collision with each solid object
    libraryLayout.forEach(object => {
      if (!object.solid) return;
      
      // Simple rectangular collision detection
      const objectLeft = object.position[0] - object.size[0] / 2;
      const objectRight = object.position[0] + object.size[0] / 2;
      const objectTop = object.position[1] - object.size[1] / 2;
      const objectBottom = object.position[1] + object.size[1] / 2;
      
      // Find closest point on rectangle to player center
      const closestX = Math.max(objectLeft, Math.min(playerPosition[0], objectRight));
      const closestY = Math.max(objectTop, Math.min(playerPosition[1], objectBottom));
      
      // Calculate distance from player center to closest point
      const distanceX = playerPosition[0] - closestX;
      const distanceY = playerPosition[1] - closestY;
      const distanceSquared = distanceX * distanceX + distanceY * distanceY;
      
      // If distance is less than player radius, there's a collision
      if (distanceSquared < playerRadius * playerRadius) {
        // Simple collision response: push player out
        const distance = Math.sqrt(distanceSquared);
        const overlapDistance = playerRadius - distance;
        
        if (distance > 0) {
          const pushX = (distanceX / distance) * overlapDistance;
          const pushY = (distanceY / distance) * overlapDistance;
          
          set(state => ({
            playerPosition: [
              state.playerPosition[0] + pushX,
              state.playerPosition[1] + pushY
            ]
          }));
        }
      }
    });
  },
  
  // Highlight book when player is nearby
  highlightBook: (id: number | null) => {
    set({ highlightedBookId: id });
  },
  
  // Check for book interaction
  checkBookInteraction: () => {
    const { highlightedBookId } = get();
    
    if (highlightedBookId !== null) {
      get().openBook(highlightedBookId);
    }
  },
  
  // Open a book to read its content
  openBook: (id: number) => {
    const { books } = get();
    const book = books.find(b => b.id === id);
    
    if (book) {
      set({ 
        activeBook: book,
        gameState: "paused"
      });
    }
  },
  
  // Close the active book
  closeBook: () => {
    set({ 
      activeBook: null,
      gameState: "playing"
    });
  }
}));
