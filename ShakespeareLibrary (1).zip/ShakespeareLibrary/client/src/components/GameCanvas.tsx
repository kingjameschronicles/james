import { useRef, useEffect } from "react";
import { useLibraryGame } from "../lib/stores/useLibraryGame";
import { useAudio } from "../lib/stores/useAudio";
import Library from "./Library";
import Player from "./Player";

const GameCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestIdRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);
  
  const { 
    playerPosition, 
    movePlayer, 
    checkBookInteraction, 
    checkCollisions,
    updateGameState,
    initializeGame
  } = useLibraryGame();
  
  const { isMuted, toggleMute, backgroundMusic } = useAudio();

  // Initialize game state when component mounts
  useEffect(() => {
    console.log("GameCanvas: Initializing game state");
    
    // Only initialize game when this component first mounts
    // This should be a one-time operation to set up game state
    initializeGame();
    
    // Cleanup function
    return () => {
      console.log("GameCanvas: Cleanup on unmount");
      cancelAnimationFrame(requestIdRef.current);
    };
  }, [initializeGame]);
  
  // Handle background music playback separately
  useEffect(() => {
    console.log("GameCanvas: Setting up background music");
    
    // Start background music if not muted
    if (backgroundMusic && !isMuted) {
      console.log("GameCanvas: Starting background music");
      backgroundMusic.play().catch(error => {
        console.log("Background music play prevented:", error);
      });
    }
    
    // Cleanup background music on unmount
    return () => {
      if (backgroundMusic) {
        console.log("GameCanvas: Stopping background music on cleanup");
        backgroundMusic.pause();
      }
    };
  }, [backgroundMusic, isMuted]);
  
  // Set up keyboard event handlers
  useEffect(() => {
    console.log("GameCanvas: Setting up keyboard controls");
    
    // Handle keyboard input
    const handleKeyDown = (event: KeyboardEvent) => {
      const { key } = event;
      
      // Movement keys
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 'a', 's', 'd', 'W', 'A', 'S', 'D'].includes(key)) {
        event.preventDefault();
        let direction: [number, number] = [0, 0];
        
        switch (key.toLowerCase()) {
          case 'w':
          case 'arrowup':
            direction = [0, -1];
            break;
          case 's':
          case 'arrowdown':
            direction = [0, 1];
            break;
          case 'a':
          case 'arrowleft':
            direction = [-1, 0];
            break;
          case 'd':
          case 'arrowright':
            direction = [1, 0];
            break;
        }
        
        console.log("GameCanvas: Moving player in direction:", direction);
        movePlayer(direction);
      }
      
      // Interaction key
      if (key === 'e' || key === 'E') {
        console.log("GameCanvas: Interaction key pressed");
        checkBookInteraction();
      }
      
      // Mute/unmute
      if (key === 'm' || key === 'M') {
        console.log("GameCanvas: Mute toggle key pressed");
        toggleMute();
        
        if (backgroundMusic) {
          if (isMuted) {
            console.log("GameCanvas: Unmuting - playing music");
            backgroundMusic.play().catch(error => {
              console.log("Background music play prevented:", error);
            });
          } else {
            console.log("GameCanvas: Muting - pausing music");
            backgroundMusic.pause();
          }
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    
    return () => {
      console.log("GameCanvas: Removing keyboard event listener");
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [movePlayer, checkBookInteraction, toggleMute, isMuted, backgroundMusic]);

  // Game loop
  useEffect(() => {
    const animate = (time: number) => {
      if (!lastTimeRef.current) {
        lastTimeRef.current = time;
      }
      
      const deltaTime = time - lastTimeRef.current;
      lastTimeRef.current = time;
      
      // Update game state
      updateGameState(deltaTime);
      
      // Check for collisions
      checkCollisions();
      
      // Continue animation loop
      requestIdRef.current = requestAnimationFrame(animate);
    };
    
    requestIdRef.current = requestAnimationFrame(animate);
    
    return () => {
      cancelAnimationFrame(requestIdRef.current);
    };
  }, [updateGameState, checkCollisions]);

  return (
    <div className="game-canvas-container">
      <div className="game-canvas-wrapper">
        <Library />
        <Player position={playerPosition} />
      </div>
      
      <button 
        className="mute-button" 
        onClick={() => {
          toggleMute();
          if (backgroundMusic) {
            if (isMuted) {
              backgroundMusic.play().catch(err => console.log(err));
            } else {
              backgroundMusic.pause();
            }
          }
        }}
      >
        <i className={`fa ${isMuted ? 'fa-volume-mute' : 'fa-volume-up'}`}></i>
      </button>
    </div>
  );
};

export default GameCanvas;
