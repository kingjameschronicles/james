import React, { useState, useEffect } from "react";
import { useLibraryGame } from "../lib/stores/useLibraryGame";
import { useAudio } from "../lib/stores/useAudio";
import { BookData } from "../lib/stores/useLibraryGame";

interface BookProps {
  book: BookData;
}

const Book: React.FC<BookProps> = ({ book }) => {
  const playerPosition = useLibraryGame(state => state.playerPosition);
  const highlightBook = useLibraryGame(state => state.highlightBook);
  const [isNearby, setIsNearby] = useState(false);
  const { playHit } = useAudio();
  
  // Check if player is near this book
  useEffect(() => {
    const bookPos = book.position;
    const playerPos = playerPosition;
    
    // Calculate distance between player and book
    const distance = Math.sqrt(
      Math.pow(bookPos[0] - playerPos[0], 2) + 
      Math.pow(bookPos[1] - playerPos[1], 2)
    );
    
    // If player is within interaction range
    const wasNearby = isNearby;
    const newIsNearby = distance < 80;
    setIsNearby(newIsNearby);
    
    // Notify store about highlighted book
    if (newIsNearby) {
      highlightBook(book.id);
      
      // Play hit sound when player enters book range
      if (!wasNearby) {
        playHit();
      }
    } else if (wasNearby) {
      highlightBook(null);
    }
  }, [book, playerPosition, highlightBook, isNearby, playHit]);

  return (
    <div 
      className={`book-object ${isNearby ? 'book-highlight' : ''}`}
      style={{
        left: `${book.position[0]}px`,
        top: `${book.position[1]}px`,
        zIndex: Math.floor(book.position[1])
      }}
    >
      <div className="book-sprite" style={{ backgroundColor: book.color }}></div>
      
      {isNearby && (
        <div className="book-interaction-hint">
          <span>Press E to read</span>
        </div>
      )}
    </div>
  );
};

export default Book;
