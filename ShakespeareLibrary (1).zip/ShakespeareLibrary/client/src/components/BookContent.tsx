import React, { useEffect } from "react";
import { useAudio } from "../lib/stores/useAudio";
import { BookData } from "../lib/stores/useLibraryGame";

interface BookContentProps {
  book: BookData;
  onClose: () => void;
}

const BookContent: React.FC<BookContentProps> = ({ book, onClose }) => {
  const { playSuccess } = useAudio();
  
  // Play success sound when book is opened
  useEffect(() => {
    playSuccess();
  }, [playSuccess]);
  
  // Close book on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  return (
    <div className="book-content-overlay">
      <div className="book-content-container">
        <div className="book-content-header">
          <h2>{book.title}</h2>
          <button className="close-button" onClick={onClose}>
            <i className="fa fa-times"></i>
          </button>
        </div>
        
        <div className="book-content-body">
          {book.content.map((paragraph, idx) => (
            <p key={idx}>{paragraph}</p>
          ))}
        </div>
        
        {book.image && (
          <div className="book-content-image">
            <div className={`book-illustration illustration-${book.id}`}></div>
          </div>
        )}
        
        <div className="book-content-footer">
          <span className="book-page-number">Page {book.id} of 5</span>
          <button className="close-book-button" onClick={onClose}>
            Close Book
          </button>
        </div>
      </div>
    </div>
  );
};

export default BookContent;
