import React from "react";
import Book from "./Book";
import { useLibraryGame } from "../lib/stores/useLibraryGame";

const Library: React.FC = () => {
  const books = useLibraryGame(state => state.books);
  const libraryLayout = useLibraryGame(state => state.libraryLayout);
  
  return (
    <div className="library-container">
      {/* Library background */}
      <div className="library-floor"></div>
      
      {/* Library walls */}
      <div className="library-wall wall-top"></div>
      <div className="library-wall wall-right"></div>
      <div className="library-wall wall-bottom"></div>
      <div className="library-wall wall-left"></div>
      
      {/* Library objects (bookshelves, tables, etc.) */}
      {libraryLayout.map((object, index) => (
        <div 
          key={`library-object-${index}`}
          className={`library-object ${object.type}`}
          style={{
            left: `${object.position[0]}px`,
            top: `${object.position[1]}px`,
            width: `${object.size[0]}px`,
            height: `${object.size[1]}px`,
            zIndex: Math.floor(object.position[1])
          }}
        >
          {object.type === 'bookshelf' && (
            <div className="bookshelf-books"></div>
          )}
          {object.type === 'table' && (
            <div className="table-surface"></div>
          )}
          {object.type === 'chair' && (
            <div className="chair-seat"></div>
          )}
        </div>
      ))}
      
      {/* Interactive books */}
      {books.map((book) => (
        <Book 
          key={book.id}
          book={book}
        />
      ))}
      
      {/* Library decorations */}
      <div className="library-decoration chandelier" style={{ left: '50%', top: '30%' }}></div>
      <div className="library-decoration plant" style={{ left: '10%', top: '80%' }}></div>
      <div className="library-decoration globe" style={{ left: '80%', top: '20%' }}></div>
    </div>
  );
};

export default Library;
