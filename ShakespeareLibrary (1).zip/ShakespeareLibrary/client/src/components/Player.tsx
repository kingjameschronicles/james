import React, { useMemo } from "react";
import { useLibraryGame } from "../lib/stores/useLibraryGame";

interface PlayerProps {
  position: [number, number];
}

const Player: React.FC<PlayerProps> = ({ position }) => {
  const playerDirection = useLibraryGame(state => state.playerDirection);
  
  // Determine which sprite to use based on direction
  const spriteClass = useMemo(() => {
    switch (playerDirection) {
      case "up": return "player-sprite player-up";
      case "down": return "player-sprite player-down";
      case "left": return "player-sprite player-left";
      case "right": return "player-sprite player-right";
      default: return "player-sprite player-down";
    }
  }, [playerDirection]);

  return (
    <div 
      className={spriteClass}
      style={{
        left: `${position[0]}px`,
        top: `${position[1]}px`,
        transform: `translate(-50%, -50%)`,
        transition: 'left 0.1s ease, top 0.1s ease',
        zIndex: Math.floor(position[1])
      }}
    >
      <div className="player-shadow"></div>
    </div>
  );
};

export default Player;
