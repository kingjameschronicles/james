import React, { useEffect } from "react";
import { useLibraryGame } from "../lib/stores/useLibraryGame";
import { useAudio } from "../lib/stores/useAudio";

const StartScreen: React.FC = () => {
  const startGame = useLibraryGame(state => state.startGame);
  const { backgroundMusic, toggleMute, isMuted } = useAudio();
  
  // Debug logging on mount
  useEffect(() => {
    console.log("StartScreen mounted");
    console.log("Initial game state:", useLibraryGame.getState().gameState);
    console.log("Initial audio state - isMuted:", isMuted);
    console.log("Background music loaded:", !!backgroundMusic);
  }, [isMuted, backgroundMusic]);
  
  // Start background music when user clicks play
  const handleStartGame = () => {
    console.log("Start game button clicked");
    
    if (backgroundMusic && isMuted) {
      console.log("Unmuting audio");
      toggleMute();
      backgroundMusic.play().catch(err => console.log("Error playing music:", err));
    } else {
      console.log("Audio already unmuted or no background music");
    }
    
    console.log("Calling startGame()");
    startGame();
    console.log("New game state:", useLibraryGame.getState().gameState);
  };
  
  // Handle Enter key to start game
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Enter") {
        console.log("Enter key pressed");
        handleStartGame();
      }
    };
    
    console.log("Adding Enter key event listener");
    window.addEventListener("keydown", handleKeyDown);
    
    return () => {
      console.log("Removing Enter key event listener");
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  return (
    <div className="start-screen">
      <div className="start-screen-content">
        <h1 className="game-title">The King's Library</h1>
        <h2 className="game-subtitle">King James I & Shakespeare's Theater</h2>
        
        <div className="instruction-container">
          <h3>Instructions</h3>
          <ul>
            <li><i className="fa fa-arrow-up"></i> <i className="fa fa-arrow-down"></i> <i className="fa fa-arrow-left"></i> <i className="fa fa-arrow-right"></i> or WASD to move</li>
            <li><strong>E</strong> to interact with books</li>
            <li><strong>ESC</strong> to close books</li>
            <li><strong>M</strong> to mute/unmute audio</li>
          </ul>
          
          <p className="instruction-text">
            Explore the library to discover books containing information about 
            King James I's influence on Shakespeare and the theater.
          </p>
        </div>
        
        <button 
          className="start-button" 
          onClick={handleStartGame}
          style={{
            cursor: 'pointer',
            fontSize: '1.5rem',
            padding: '1rem 2rem',
            backgroundColor: '#3d5a80',
            color: 'white',
            border: 'none',
            borderRadius: '0.5rem',
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.3)',
            transition: 'all 0.3s ease'
          }}
          onMouseOver={(e) => {
            e.currentTarget.style.backgroundColor = '#2c3e50';
            e.currentTarget.style.transform = 'translateY(-3px)';
            e.currentTarget.style.boxShadow = '0 6px 8px rgba(0, 0, 0, 0.4)';
          }}
          onMouseOut={(e) => {
            e.currentTarget.style.backgroundColor = '#3d5a80';
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.3)';
          }}
        >
          <i className="fa fa-play"></i> Enter The Library
        </button>
      </div>
    </div>
  );
};

export default StartScreen;
